# CreateStreamRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**delivery** | [**Delivery**](Delivery.md) |  | 
**eventRequested** | **List&lt;String&gt;** |  | 
**description** | **String** |  |  [optional]
