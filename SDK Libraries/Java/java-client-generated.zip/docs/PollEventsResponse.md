# PollEventsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sets** | **Map&lt;String, Object&gt;** |  |  [optional]
