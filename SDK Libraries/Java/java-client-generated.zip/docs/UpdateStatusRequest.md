# UpdateStatusRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streamId** | **String** |  | 
**status** | **String** |  | 
**description** | **String** |  |  [optional]
