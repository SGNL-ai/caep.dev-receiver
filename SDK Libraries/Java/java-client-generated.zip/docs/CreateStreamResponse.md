# CreateStreamResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streamId** | **String** |  |  [optional]
**iss** | **String** |  |  [optional]
**aud** | **String** |  |  [optional]
**eventsSupported** | **List&lt;String&gt;** |  |  [optional]
**eventsRequested** | **List&lt;String&gt;** |  |  [optional]
**eventsDelivered** | **List&lt;String&gt;** |  |  [optional]
**description** | **String** |  |  [optional]
**delivery** | [**Delivery**](Delivery.md) |  |  [optional]
