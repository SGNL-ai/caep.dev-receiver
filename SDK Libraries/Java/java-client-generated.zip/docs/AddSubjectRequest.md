# AddSubjectRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streamId** | **String** |  | 
**verified** | **Boolean** |  | 
**subject** | **Map&lt;String, Object&gt;** |  | 
