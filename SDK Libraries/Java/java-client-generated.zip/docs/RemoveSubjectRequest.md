# RemoveSubjectRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streamId** | **String** |  | 
**subject** | **Map&lt;String, Object&gt;** |  | 
