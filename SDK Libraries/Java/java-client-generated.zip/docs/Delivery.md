# Delivery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deliveryMethod** | **String** |  | 
**endpointUrl** | **String** |  |  [optional]
