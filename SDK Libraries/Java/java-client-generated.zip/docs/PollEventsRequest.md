# PollEventsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**maxEvents** | **Integer** |  |  [optional]
**returnImmediately** | **Boolean** |  |  [optional]
**ack** | **List&lt;String&gt;** |  | 
